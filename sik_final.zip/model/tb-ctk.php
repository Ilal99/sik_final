<tr>
    <td colspan='3'></td>
</tr>
<tr class='success'>
    <td colspan='3' align='center'>
        <font color='#000000' size='4' style='font-weight: bold;' ;>DAFTAR NILAI MADRASAH
    </td>
</tr>
<tr class='danger'>
    <td width='50'>Nama Mata Pelajaran</td>
    <td width='50' align='center'><strong> Nilai </strong></td>
</tr>

<tr class='warning'>
    <td colspan='3' align='center'><b>Kelompok A (Umum)</b></td>
</tr <tr class='warning'>
<td colspan='3'>1. Pendidikan Agama Islam</td>
</tr <tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp; a. Alquran Hadist</td>
<td colspan='3' align='center'><strong> " . $data['1'] . "</strong></td>
</tr>
<tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp; b. Akidah Akhlak</td>
    <td colspan='3' align='center'><strong> " . $data['2'] . "</strong></td>
</tr>
<tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp; c. Fikih</td>
    <td colspan='3' align='center'><strong> " . $data['3'] . "</strong></td>
</tr>
<tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp; d. Sejarah Kebudayaan Islam</td>
    <td colspan='3' align='center'><strong> " . $data['4'] . "</strong></td>
</tr>

<tr>
    <td>2. Pendidikan Pancasila dan Kewarganegaraan</td>
    <td colspan='3' align='center'><strong> " . $data['5'] . "</strong></td>
</tr>
<tr>
    <td>3. Bahasa Indonesia</td>
    <td colspan='3' align='center'><strong> " . $data['6'] . "</strong></td>
</tr>
<tr>
    <td>4. Bahasa Arab</td>
    <td colspan='3' align='center'><strong> " . $data['7'] . "</strong></td>
</tr>
<tr>
    <td>5. Matematika</td>
    <td colspan='3' align='center'><strong> " . $data['8'] . "</strong></td>
</tr>
<tr>
    <td>6. Sejarah Indonesia</td>
    <td colspan='3' align='center'><strong> " . $data['9'] . "</strong></td>
</tr>
<tr>
    <td>7. Bahasa Inggris</td>
    <td colspan='3' align='center'><strong> " . $data['10'] . "</strong></td>
</tr>

<tr class='warning'>
    <td colspan='3' align='center'><b>Kelompok B (Umum)</b></td>
</tr <tr>
<td>1. Seni Budaya</td>
<td colspan='3' align='center'><strong> " . $data['11'] . "</strong></td>
</tr>
<tr>
    <td>2. Pendidikan Jasmani, Olahraga, dan Kesehatan</td>
    <td colspan='3' align='center'><strong> " . $data['12'] . "</strong></td>
</tr>
<tr>
    <td>3. Prakarya dan Kewirausahaan</td>
    <td colspan='3' align='center'><strong> " . $data['13'] . "</strong></td>
</tr>

<tr class='warning'>
    <td colspan='3' align='center'><b>Kelompok C (Peminatan)</b></td>
</tr <tr>
<td>1. " . $data['p1'] . "</td>
<td colspan='3' align='center'><strong> " . $data['14'] . "</strong></td>
</tr>
<tr>
    <td>2. " . $data['p2'] . "</td>
    <td colspan='3' align='center'><strong> " . $data['15'] . "</strong></td>
</tr>
<tr>
    <td>3. " . $data['p3'] . "</td>
    <td colspan='3' align='center'><strong> " . $data['16'] . "</strong></td>
</tr>
<tr>
    <td>4. " . $data['p4'] . "</td>
    <td colspan='3' align='center'><strong> " . $data['17'] . "</strong></td>
</tr>

<tr class='warning'>
    <td colspan='3'>5. Pilihan Lintas Minat/Pendalaman Minat</td>
</tr <tr>
<td>&nbsp;&nbsp;&nbsp;&nbsp; a. " . $data['p5'] . "</td>
<td colspan='3' align='center'><strong> " . $data['18'] . "</strong></td>
</tr>
<tr>
    <td>&nbsp;&nbsp;&nbsp;&nbsp; b. " . $data['p6'] . "</td>
    <td colspan='3' align='center'><strong> " . $data['19'] . "</strong></td>
</tr>
<tr class='danger'>
    <td width='50'><strong>Rata-Rata</strong></td>
    <td width='50' align='center'><strong>" . $data['rt'] . "</strong></td>
</tr>