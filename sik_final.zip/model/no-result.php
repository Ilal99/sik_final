<br>
</br>
<div class='container' style='height: 100%; display: flex; justify-content: center; align-items: center;'>
    <div style='top: 50%; transform:translate(0, -50%); position: absolute;'>
        <div class='well' style='margin-top: 0px;'>
            <p align='center'><img src='images/logo.png' height='75' /></p>
            <h4 align='center' style='margin: 15px 0 -10px 0;'><b>SISTEM INFORMASI</br>STATUS KELULUSAN SISWA</b></h4>
            <hr>
            <div align='center' class='alert alert-dismissable alert-success'>
                <h4><b>MAAF NISN YANG ANDA MASUKKAN </br>TIDAK TERDAFTAR DI DATABASE</b></h4>
            </div>
            <hr>
            <div class='form-group' style='margin-bottom: -10px;'>
                <p align='center'><a href='caridata' class='btn btn-danger' value=''> KEMBALI PERIKSA DATA</a></p>
            </div>
        </div>
        </br>
    </div>
</div>
<meta http-equiv='refresh' content='15; url=/sik/'>