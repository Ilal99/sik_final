<!-- <div class="well" style="margin: 10px 0 60px 0px;"> -->
<div class="well">
    <p align="center"><img src="../images/saktipng.png" height="75" /></p>
    <h4 align="center" style="margin: 15px 0 0 0;"><b>SISTEM INFORMASI<br>STATUS KELULUSAN SISWA</b></h4>
    <hr>
    <div class="alert alert-dismissable alert-success" style="margin: 0 0 10px 0;">
        <h4 align="center"><b>MENU DASHBOARD</b></h4>
    </div>
    <div class="alert alert-dismissable alert-success" style="margin: 0 0 0 0;">
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 5px 0;">
            <h4 style="font-size: 14px;"> <a class="alert-sm" href="profil" value="">
                    <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                    <b>&nbsp; ATUR PROFIL</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 5px 0;">
            <h4 style="font-size: 14px;"><a class="alert-sm" href="siswa" value="">
                    <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                    <b>&nbsp; DATA SISWA</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 5px 0;">
            <h4 style="font-size: 14px;"><a class="alert-sm" href="mapel" value="">
                    <span class="glyphicon glyphicon-book" aria-hidden="true"></span>
                    <b>&nbsp; MATA PELAJARAN</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 5px 0;">
            <h4 style="font-size: 14px;"><a class="alert-sm" href="import" value="">
                    <span class="glyphicon glyphicon-upload" aria-hidden="true"></span>
                    <b>&nbsp; UPLOAD</b></a></h4>
        </div>
        <div class="alert alert-dismissable alert-danger" style="margin: 0 0 10px 0;">
            <h4 style="font-size: 14px;"><a class="alert-sm" href="petugas" value="">
                    <span class="glyphicon glyphicon-lock" aria-hidden="true"></span>
                    <b>&nbsp; PENGGUNA</b></a></h4>
        </div>
    </div>
</div>