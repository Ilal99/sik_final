<div class="well">
    <div class="alert alert-dismissable alert-success">
        <h4 align="center"><b>SISTEM INFORMASI KELULUSAN </br>UPLOAD FILE SISWA</b></h4>
    </div>
    <div class="alert alert-dismissable alert-danger" style="margin-bottom: 0px;">
        <form method="post" enctype="multipart/form-data" action="index.php?page=importsiswa">
            FORM UPLOAD FILE EXCEL*
            <br /><br><input name="fileexcel" type="file" class="btn btn-danger"><br>
            <input name="upload" type="submit" value="UPLOAD FILE" class="btn btn-info">
            <br><br>* <b>Silahkan hapus header pada template yang berwana kuning.</b>
            <br>** PILIH FILE MICROSOFT EXCEL DENGAN FILE TYPE (.xls: 2003-2007). Silahkan Download FILE Template <a href="template_import_siswa.xls"><b>DISINI</b></a>

        </form><br>
    </div>
</div>